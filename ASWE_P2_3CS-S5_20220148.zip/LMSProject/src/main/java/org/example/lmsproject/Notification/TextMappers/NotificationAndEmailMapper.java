package org.example.lmsproject.Notification.TextMappers;

public interface NotificationAndEmailMapper {
    public abstract String getSubject();
    public abstract String getBody();
}
