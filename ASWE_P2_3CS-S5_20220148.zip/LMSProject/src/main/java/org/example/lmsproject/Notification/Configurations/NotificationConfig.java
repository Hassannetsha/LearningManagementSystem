// package org.example.lmsproject.Notification.Configurations;


// import java.time.LocalDate;
// import java.util.List;

// import org.example.lmsproject.Notification.Repositories.NotificationRepository;
// import org.springframework.boot.CommandLineRunner;
// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;


// @Configuration
// public class NotificationConfig {

//     @Bean
//     CommandLineRunner commandLineRunner(NotificationRepository repository) {
//         return args -> {
//         };
//     }
// }
